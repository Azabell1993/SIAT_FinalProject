package com.siat.blueclub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlueclubApplicationTests {

	@Test
	void contextLoads() {
	}

}
